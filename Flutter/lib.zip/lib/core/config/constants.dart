class AppConstants {
  AppConstants._();

  static const appName = 'Learnova';
}
