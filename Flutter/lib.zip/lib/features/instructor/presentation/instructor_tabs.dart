class InstructorTabs {
  static const dashboard = 0;
  static const course = 1;
  static const questionBank = 2;
  static const quizzes = 3;
  static const settings = 4;
  static const help = 5;
}

class InstructorViews {
  static const tabs = 0;
  static const notifications = 1;
  static const settings = 2;
}
