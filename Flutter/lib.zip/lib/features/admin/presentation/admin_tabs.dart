class AdminTabs {
  static const users = 0;
  static const joinRequests = 1;
  static const upgradePlans = 2;
  static const settings = 3;
  static const help = 4;
}

class AdminViews {
  static const tabs = 0;
  static const notifications = 1;
  static const settings = 2;
}
