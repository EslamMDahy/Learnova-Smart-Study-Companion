part of 'instructor_presentation_page.dart';

extension _PresentationWorkspace on _InstructorPresentationPageState {
  Future<void> _loadWorkspaceContext() async {
    final courseId = widget.courseId;
    final moduleId = widget.moduleId;
    final materialId = widget.materialId;
    if (courseId == null || moduleId == null || materialId == null) {
      if (!mounted) return;
      setState(() {
        _workspaceLoading = false;
        _workspaceError =
            'The presentation link is missing its course or material context.';
        _generationStatus = 'Invalid presentation context';
      });
      return;
    }

    setState(() {
      _workspaceLoading = true;
      _workspaceError = null;
      _workspaceTopics = const <TopicItem>[];
      _workspaceSections = const <PresentationTargetSection>[];
      _generationStatus = 'Loading selected content…';
    });

    try {
      final topicsApi = ref.read(topicsApiProvider);
      final response = await topicsApi.listTopics(
        courseId: courseId,
        moduleId: moduleId,
        materialId: materialId,
      );
      if (!mounted) return;

      final listedTopicsById = <int, TopicItem>{
        for (final TopicItem topic in response.topics) topic.id: topic,
      };
      final requestedIds = widget.selectedTopicIds;
      final requestedTopics = response.topics.where((TopicItem topic) {
        return requestedIds.isEmpty || requestedIds.contains(topic.id);
      }).toList();

      if (requestedTopics.isEmpty) {
        throw const FormatException(
          'The selected topics are no longer available in this material.',
        );
      }

      // The backend topics list endpoint intentionally returns a lightweight
      // TopicListItem and does not include page_start/page_end. Presentation
      // generation needs those values, so hydrate the selected topics (and any
      // parent used as a range source) from GET topics/{topic_id}.
      final hydratedTopicsById = <int, TopicItem>{};

      Future<TopicItem?> loadTopicDetails(int topicId) async {
        final cached = hydratedTopicsById[topicId];
        if (cached != null) return cached;

        final listed = listedTopicsById[topicId];
        if (listed == null) return null;

        try {
          final detail = await topicsApi.getTopic(
            courseId: courseId,
            moduleId: moduleId,
            materialId: materialId,
            topicId: topicId,
          );
          final hydrated = detail.topic.copyWith(
            moduleId: moduleId,
            materialId: materialId,
            pageStart: detail.topic.pageStart ?? listed.pageStart,
            pageEnd: detail.topic.pageEnd ?? listed.pageEnd,
          );
          hydratedTopicsById[topicId] = hydrated;
          return hydrated;
        } catch (_) {
          // Keep the list item so the workspace can still use material page
          // count as a safe fallback when topic ranges are unavailable.
          final normalized = listed.copyWith(
            moduleId: moduleId,
            materialId: materialId,
          );
          hydratedTopicsById[topicId] = normalized;
          return normalized;
        }
      }

      final selectedTopics = <TopicItem>[];
      for (final TopicItem listed in requestedTopics) {
        selectedTopics.add(await loadTopicDetails(listed.id) ?? listed);
      }

      selectedTopics.sort((TopicItem a, TopicItem b) {
        final startCompare = (a.pageStart ?? (1 << 30))
            .compareTo(b.pageStart ?? (1 << 30));
        if (startCompare != 0) return startCompare;
        return a.orderIndex.compareTo(b.orderIndex);
      });

      int? materialPageCount = widget.materialPageCount;
      if (materialPageCount == null || materialPageCount <= 0) {
        try {
          final materialsResponse =
              await ref.read(materialsApiProvider).listMaterials(
                    courseId: courseId,
                    moduleId: moduleId,
                  );
          for (final material in materialsResponse.materials) {
            if (material.id == materialId) {
              materialPageCount = material.pageCount;
              break;
            }
          }
        } catch (_) {
          // Topic ranges remain the primary source. Missing material metadata
          // is handled below only when no usable section can be constructed.
        }
      }

      final sections = <PresentationTargetSection>[];

      for (final TopicItem topic in selectedTopics) {
        TopicItem? rangeSource = topic;
        final visitedTopicIds = <int>{topic.id};

        while (rangeSource != null &&
            rangeSource.pageStart == null &&
            rangeSource.pageEnd == null &&
            rangeSource.parentTopicId != null) {
          final parentId = rangeSource.parentTopicId!;
          if (!visitedTopicIds.add(parentId)) break;
          rangeSource = await loadTopicDetails(parentId);
        }

        int? pageStart = rangeSource?.pageStart;
        int? pageEnd = rangeSource?.pageEnd;
        if (pageStart == null && pageEnd != null) pageStart = pageEnd;
        if (pageEnd == null && pageStart != null) pageEnd = pageStart;

        if (pageStart == null || pageEnd == null) {
          final pageCount = materialPageCount;
          if (pageCount != null && pageCount > 0) {
            pageStart = 1;
            pageEnd = pageCount;
          }
        }

        if (pageStart == null || pageEnd == null) continue;
        final normalizedStart = math.min(pageStart, pageEnd);
        final normalizedEnd = math.max(pageStart, pageEnd);
        sections.add(
          PresentationTargetSection(
            topicId: topic.id,
            topicTitle: topic.title,
            pageStart: normalizedStart,
            pageEnd: normalizedEnd,
          ),
        );
      }

      if (sections.isEmpty) {
        throw const FormatException(
          'The selected topics have no page ranges and the material has no page count. Add page ranges to the topics before generating a presentation.',
        );
      }

      if (!mounted) return;
      setState(() {
        _workspaceTopics = selectedTopics;
        _workspaceSections = sections;
        _slideCount = math.max(6, sections.length + 2).clamp(4, 30).toInt();
        _workspaceLoading = false;
        _generationStatus = 'Ready to generate';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _workspaceLoading = false;
        _workspaceError = _presentationErrorMessage(error);
        _generationStatus = 'Content could not be loaded';
      });
    }
  }

  Future<void> _generatePresentationFromWorkspace() async {
    final courseId = widget.courseId;
    final materialId = widget.materialId;
    if (courseId == null || materialId == null || _workspaceSections.isEmpty) {
      return;
    }
    if (_isGenerating) return;

    _generationCancelToken?.cancel('Starting a new presentation request.');
    _streamCancelToken?.cancel('Starting a new presentation request.');
    _generationCancelToken = CancelToken();
    _streamCancelToken = null;

    setState(() {
      _isGenerating = true;
      _workspaceError = null;
      _generationStatus = 'Generating presentation slides…';
      _deck = null;
      _selectedSlide = 0;
    });

    try {
      final api = ref.read(presentationApiProvider);
      final response = await api.generatePresentation(
        courseId: courseId,
        materialId: materialId,
        payload: GeneratePresentationRequest(
          slideCount: _slideCount,
          targetSections: _workspaceSections,
        ),
        cancelToken: _generationCancelToken,
      );

      if (!response.isProcessing) {
        throw FormatException(
          response.status.trim().isEmpty
              ? 'The presentation request was not accepted.'
              : 'Unexpected generation status: ${response.status}',
        );
      }

      if (!mounted) return;
      setState(() {
        _generationStatus = 'Waiting for the generated presentation…';
      });

      // The callback result is persisted in ai_request_logs. Poll the result
      // endpoint directly instead of depending on a one-shot PostgreSQL NOTIFY
      // event, which can be missed if the SSE listener is not fully attached
      // when the AI callback arrives.
      final resolvedResult = await _loadPresentationResultWithRetry(
        courseId: courseId,
        materialId: materialId,
      );

      if (!mounted) return;
      setState(() => _generationStatus = 'Preparing the presentation preview…');

      final deck =
          PresentationCodeParser.parse(jsonEncode(resolvedResult.deckJson));
      if (deck.slides.isEmpty) {
        throw const FormatException('The AI returned an empty presentation.');
      }

      if (!mounted) return;
      setState(() {
        _deck = deck;
        _selectedSlide = 0;
        _generationStatus = 'Presentation ready';
        _isGenerating = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _isGenerating = false;
        _workspaceError = _presentationErrorMessage(error);
        _generationStatus = 'Generation failed';
      });
    }
  }

  Future<PresentationGenerationResult> _loadPresentationResultWithRetry({
    required int courseId,
    required int materialId,
  }) async {
    Object? lastError;

    // First attempts are intentionally frequent because the callback often
    // arrives quickly. After that, poll every two seconds for up to ten
    // minutes, matching the previous SSE wait window.
    const maxAttempts = 305;
    for (var attempt = 0; attempt < maxAttempts; attempt++) {
      try {
        return await ref.read(presentationApiProvider).getPresentationResult(
              courseId: courseId,
              materialId: materialId,
              cancelToken: _generationCancelToken,
            );
      } catch (error) {
        lastError = error;
        if (attempt == maxAttempts - 1) rethrow;

        await Future<void>.delayed(
          attempt < 10
              ? const Duration(seconds: 1)
              : const Duration(seconds: 2),
        );
      }
    }

    throw lastError ?? const FormatException('Presentation result not found.');
  }

  String _presentationErrorMessage(Object error) {
    if (error is FormatException) {
      final message = error.message.toString().trim();
      if (message.isNotEmpty) return message;
    }
    return mapApiError(error);
  }

  void _goBackToCourseMaterials() {
    final slug = widget.courseSlug;
    if (slug == null || slug.trim().isEmpty) {
      context.go(Routes.instructorCourses);
      return;
    }
    context.go(Routes.courseMaterials(slug));
  }

  Widget _buildPresentationWorkspace(BuildContext context) {
    final deck = _deck;
    final selectedSlide = deck == null || deck.slides.isEmpty
        ? null
        : deck.slides[_selectedSlide.clamp(0, deck.slides.length - 1).toInt()];

    final preview = _DeckPreviewPanel(
      deck: deck,
      selectedSlide: _selectedSlide,
      showExtractedText: _showExtractedText,
      onShowExtractedTextChanged: (bool value) {
        setState(() => _showExtractedText = value);
      },
      onSlideSelected: (int index) {
        setState(() => _selectedSlide = index);
      },
      onDownload: _downloadDeck,
      isDownloading: _isExportingPptx,
      onEditSlide:
          selectedSlide?.usesCardEditor == true ? _editSelectedSlide : null,
      onDuplicateSlide: deck == null ? null : _duplicateSelectedSlide,
      onDeleteSlide:
          deck != null && deck.slides.length > 1 ? _deleteSelectedSlide : null,
      emptyState: _PresentationWorkspaceEmptyPreview(
        loading: _workspaceLoading,
        generating: _isGenerating,
        error: _workspaceError,
        status: _generationStatus,
      ),
    );

    return Container(
      color: AppColors.pageBg,
      child: Column(
        children: [
          _PresentationWorkspaceHeader(
            courseTitle: widget.courseTitle,
            materialTitle: widget.materialTitle,
            onBack: _goBackToCourseMaterials,
          ),
          Expanded(
            child: LayoutBuilder(
              builder: (BuildContext context, BoxConstraints constraints) {
                final wide = constraints.maxWidth >= 1120;
                final setup = _PresentationSetupPanel(
                  courseTitle: widget.courseTitle,
                  materialTitle: widget.materialTitle,
                  topics: _workspaceTopics,
                  sections: _workspaceSections,
                  slideCount: _slideCount,
                  loading: _workspaceLoading,
                  generating: _isGenerating,
                  status: _generationStatus,
                  error: _workspaceError,
                  canGenerate: !_workspaceLoading &&
                      !_isGenerating &&
                      _workspaceSections.isNotEmpty,
                  onSlideCountChanged: (int value) {
                    setState(() => _slideCount = value);
                  },
                  onGenerate: _generatePresentationFromWorkspace,
                  onRetryLoad: _loadWorkspaceContext,
                );

                return SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(24, 24, 24, 40),
                  child: wide
                      ? Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(width: 360, child: setup),
                            const SizedBox(width: 22),
                            Expanded(child: preview),
                          ],
                        )
                      : Column(
                          children: [
                            setup,
                            const SizedBox(height: 22),
                            preview,
                          ],
                        ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _PresentationWorkspaceHeader extends StatelessWidget {
  final String? courseTitle;
  final String? materialTitle;
  final VoidCallback onBack;

  const _PresentationWorkspaceHeader({
    required this.courseTitle,
    required this.materialTitle,
    required this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    final course = (courseTitle ?? 'Course').trim();
    final material = (materialTitle ?? 'Selected material').trim();

    return Container(
      height: 68,
      padding: const EdgeInsets.symmetric(horizontal: 24),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        border: Border(bottom: BorderSide(color: AppColors.border)),
      ),
      child: Row(
        children: [
          IconButton.outlined(
            tooltip: 'Back to course materials',
            onPressed: onBack,
            icon: const Icon(Icons.arrow_back_rounded),
          ),
          const SizedBox(width: 14),
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.purpleBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              Icons.slideshow_rounded,
              color: AppColors.purpleText,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'AI Presentation Workspace',
                  style: AppTextStyles.label.copyWith(fontSize: 16),
                ),
                const SizedBox(height: 2),
                Text(
                  '$course  •  $material',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.mutedSmall,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PresentationSetupPanel extends StatelessWidget {
  final String? courseTitle;
  final String? materialTitle;
  final List<TopicItem> topics;
  final List<PresentationTargetSection> sections;
  final int slideCount;
  final bool loading;
  final bool generating;
  final String status;
  final String? error;
  final bool canGenerate;
  final ValueChanged<int> onSlideCountChanged;
  final VoidCallback onGenerate;
  final VoidCallback onRetryLoad;

  const _PresentationSetupPanel({
    required this.courseTitle,
    required this.materialTitle,
    required this.topics,
    required this.sections,
    required this.slideCount,
    required this.loading,
    required this.generating,
    required this.status,
    required this.error,
    required this.canGenerate,
    required this.onSlideCountChanged,
    required this.onGenerate,
    required this.onRetryLoad,
  });

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppColors.primarySoft,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  Icons.auto_awesome_rounded,
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Presentation setup', style: AppTextStyles.h3),
                    const SizedBox(height: 3),
                    Text(
                      'Generate editable slides from the selected course content.',
                      style: AppTextStyles.mutedSmall,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          _WorkspaceSourceCard(
            icon: Icons.menu_book_rounded,
            label: 'Course',
            value: (courseTitle ?? 'Current course').trim(),
          ),
          const SizedBox(height: 8),
          _WorkspaceSourceCard(
            icon: Icons.picture_as_pdf_rounded,
            label: 'Material',
            value: (materialTitle ?? 'Selected material').trim(),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Text('Selected sections', style: AppTextStyles.label),
              const Spacer(),
              Text(
                '${sections.length}',
                style: AppTextStyles.mutedSmall.copyWith(
                  color: AppColors.primary,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (loading)
            const _WorkspaceLoadingSections()
          else if (sections.isEmpty)
            _WorkspaceInlineError(
              message: error ?? 'No valid topic sections were found.',
              onRetry: onRetryLoad,
            )
          else
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 260),
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: sections.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (BuildContext context, int index) {
                  final section = sections[index];
                  TopicItem? matchingTopic;
                  for (final TopicItem topic in topics) {
                    if (topic.id == section.topicId) {
                      matchingTopic = topic;
                      break;
                    }
                  }
                  return _WorkspaceSectionTile(
                    section: section,
                    topic: matchingTopic,
                  );
                },
              ),
            ),
          const SizedBox(height: 20),
          Row(
            children: [
              Text('Number of slides', style: AppTextStyles.label),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: AppColors.primarySoft,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  '$slideCount slides',
                  style: AppTextStyles.mutedSmall.copyWith(
                    color: AppColors.primary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          Slider(
            min: 4,
            max: 30,
            divisions: 26,
            value: slideCount.toDouble().clamp(4.0, 30.0).toDouble(),
            label: '$slideCount',
            onChanged: generating
                ? null
                : (double value) => onSlideCountChanged(value.round()),
          ),
          _WorkspaceStatusBanner(
            status: status,
            error: error,
            active: generating || loading,
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: canGenerate ? onGenerate : null,
              icon: generating
                  ? const SizedBox(
                      width: 17,
                      height: 17,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.auto_awesome_rounded),
              label: Text(
                generating ? 'Generating presentation…' : 'Generate presentation',
              ),
              style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 15),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _WorkspaceSourceCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _WorkspaceSourceCard({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surfaceMuted,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: AppColors.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: AppTextStyles.mutedSmall),
                const SizedBox(height: 2),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.label,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _WorkspaceSectionTile extends StatelessWidget {
  final PresentationTargetSection section;
  final TopicItem? topic;

  const _WorkspaceSectionTile({required this.section, this.topic});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: AppColors.purpleBg,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              topic?.parentTopicId == null
                  ? Icons.topic_outlined
                  : Icons.subdirectory_arrow_right_rounded,
              size: 17,
              color: AppColors.purpleText,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  section.topicTitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.label.copyWith(fontSize: 13),
                ),
                const SizedBox(height: 3),
                Text(
                  'Pages ${section.pageStart}–${section.pageEnd}',
                  style: AppTextStyles.mutedSmall,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _WorkspaceStatusBanner extends StatelessWidget {
  final String status;
  final String? error;
  final bool active;

  const _WorkspaceStatusBanner({
    required this.status,
    required this.error,
    required this.active,
  });

  @override
  Widget build(BuildContext context) {
    final hasError = error != null && error!.trim().isNotEmpty;
    final background = hasError
        ? AppColors.dangerBg
        : active
            ? AppColors.infoBg
            : AppColors.successBg;
    final border = hasError
        ? AppColors.dangerBorder
        : active
            ? AppColors.infoBorder
            : AppColors.greenBorder;
    final foreground = hasError
        ? AppColors.dangerText
        : active
            ? AppColors.infoText
            : AppColors.successText;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (active)
            SizedBox(
              width: 17,
              height: 17,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: foreground,
              ),
            )
          else
            Icon(
              hasError ? Icons.error_outline_rounded : Icons.check_circle_outline,
              size: 18,
              color: foreground,
            ),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              hasError ? error! : status,
              style: AppTextStyles.mutedSmall.copyWith(
                color: foreground,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _WorkspaceInlineError extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const _WorkspaceInlineError({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.dangerBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.dangerBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            message,
            style: AppTextStyles.mutedSmall.copyWith(
              color: AppColors.dangerText,
            ),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: onRetry,
            icon: const Icon(Icons.refresh_rounded, size: 17),
            label: const Text('Reload content'),
          ),
        ],
      ),
    );
  }
}

class _WorkspaceLoadingSections extends StatelessWidget {
  const _WorkspaceLoadingSections();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surfaceMuted,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: const Center(
        child: SizedBox(
          width: 24,
          height: 24,
          child: CircularProgressIndicator(strokeWidth: 2.4),
        ),
      ),
    );
  }
}

class _PresentationWorkspaceEmptyPreview extends StatelessWidget {
  final bool loading;
  final bool generating;
  final String? error;
  final String status;

  const _PresentationWorkspaceEmptyPreview({
    required this.loading,
    required this.generating,
    required this.error,
    required this.status,
  });

  @override
  Widget build(BuildContext context) {
    final hasError = error != null && error!.trim().isNotEmpty;
    return ConstrainedBox(
      constraints: const BoxConstraints(minHeight: 560),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 82,
                height: 82,
                decoration: BoxDecoration(
                  color: hasError
                      ? AppColors.dangerBg
                      : AppColors.purpleBg,
                  shape: BoxShape.circle,
                ),
                child: generating || loading
                    ? Padding(
                        padding: const EdgeInsets.all(27),
                        child: CircularProgressIndicator(
                          strokeWidth: 3,
                          color: AppColors.purpleText,
                        ),
                      )
                    : Icon(
                        hasError
                            ? Icons.error_outline_rounded
                            : Icons.co_present_rounded,
                        color: hasError
                            ? AppColors.dangerText
                            : AppColors.purpleText,
                        size: 38,
                      ),
              ),
              const SizedBox(height: 20),
              Text(
                generating
                    ? 'Building your presentation'
                    : hasError
                        ? 'Presentation is not ready'
                        : 'Your presentation will appear here',
                textAlign: TextAlign.center,
                style: AppTextStyles.h3,
              ),
              const SizedBox(height: 9),
              SizedBox(
                width: 480,
                child: Text(
                  hasError
                      ? error!
                      : generating || loading
                          ? status
                          : 'Review the selected topics and slide count, then generate an editable presentation you can preview and download as PowerPoint.',
                  textAlign: TextAlign.center,
                  style: AppTextStyles.muted,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
