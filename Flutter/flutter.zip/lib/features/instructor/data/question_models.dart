// ─────────────────────────────────────────────────────────────────────────────
//  Question Bank — models
//  In-memory + backend-ready (fromJson / toJson wired to real DB schema).
// ─────────────────────────────────────────────────────────────────────────────

import 'question_vocabulary.dart';

enum QuestionType { multipleChoice, trueFalse, shortAnswer, essay, multiSelect, fillInTheBlank, numeric, code }
enum QuestionDifficulty { easy, medium, hard }
enum QuestionSource { manual, aiGenerated, nativeExtraction, imported }
enum QuestionApprovalStatus { pending, approved, rejected }

class QuestionOption {
  final String id;
  final String text;
  final bool isCorrect;
  final String? explanation;
  final int orderIndex;

  const QuestionOption({
    required this.id,
    required this.text,
    this.isCorrect = false,
    this.explanation,
    this.orderIndex = 0,
  });

  factory QuestionOption.fromJson(Map<String, dynamic> json) {
    return QuestionOption(
      id: json['id']?.toString() ?? json['order_index']?.toString() ?? '0',
      text: (json['option_text'] ?? json['text'] ?? '').toString(),
      isCorrect: (json['is_correct'] as bool?) ?? false,
      explanation: json['explanation']?.toString(),
      orderIndex: (json['order_index'] as num?)?.toInt() ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
    'option_text': text,
    'is_correct': isCorrect,
    'order_index': orderIndex,
    if (explanation != null) 'explanation': explanation,
  };
}


class QuestionLearningOutcomeRef {
  final int id;
  final String title;

  const QuestionLearningOutcomeRef({required this.id, required this.title});

  factory QuestionLearningOutcomeRef.fromJson(Map<String, dynamic> json) {
    return QuestionLearningOutcomeRef(
      id: (json['id'] as num).toInt(),
      title: (json['title'] ?? '').toString(),
    );
  }
}

class QuestionModel {
  // IDs — local uses String (uuid), remote uses int
  final String id;
  final int? remoteId;         // null until synced with backend

  final String text;           // question_text in DB
  final QuestionType type;
  final QuestionDifficulty difficulty;
  final QuestionSource source;
  final QuestionApprovalStatus approvalStatus;

  final List<QuestionOption> options; // MC / multi-select
  final String? correctOptionId;      // MC only
  final bool? correctBool;            // true_false
  final String? sampleAnswer;         // short_answer / essay / fill_in_blank
  final String? explanation;
  final String? expectedAnswer;
  final Object? gradingRubric;
  final List<String> tags;

  // Statistics (from backend)
  final int usageCount;
  final double? successRate;
  final double? averageTimeSeconds;
  final int maxScore;
  final bool autoGradable;

  // Hierarchy context
  final int? courseId;
  final int? moduleId;
  final String? moduleName;
  final int? materialId;
  final String? materialName;
  final int? topicId;
  final String? topicName;
  final List<QuestionLearningOutcomeRef> learningOutcomes;
  final int? createdBy;

  final DateTime createdAt;
  final DateTime updatedAt;

  const QuestionModel({
    required this.id,
    this.remoteId,
    required this.text,
    required this.type,
    required this.difficulty,
    this.source = QuestionSource.manual,
    this.approvalStatus = QuestionApprovalStatus.approved,
    this.options = const [],
    this.correctOptionId,
    this.correctBool,
    this.sampleAnswer,
    this.explanation,
    this.expectedAnswer,
    this.gradingRubric,
    this.tags = const [],
    this.usageCount = 0,
    this.successRate,
    this.averageTimeSeconds,
    this.maxScore = 1,
    this.autoGradable = true,
    this.courseId,
    this.moduleId,
    this.moduleName,
    this.materialId,
    this.materialName,
    this.topicId,
    this.topicName,
    this.learningOutcomes = const [],
    this.createdBy,
    required this.createdAt,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? createdAt;

  String get typeLabel => type.label;

  String get difficultyLabel => difficulty.label;

  String get contextLabel {
    if (topicName != null)    return topicName!;
    if (materialName != null) return materialName!;
    if (moduleName != null)   return moduleName!;
    return 'General';
  }

  /// Parse a backend Question row into a QuestionModel.
  factory QuestionModel.fromJson(Map<String, dynamic> json, {bool includeDetails = true}) {
    DateTime dt(dynamic v) =>
        DateTime.tryParse((v ?? '').toString()) ??
        DateTime.fromMillisecondsSinceEpoch(0);


    QuestionApprovalStatus parseApproval(String raw) {
      switch (raw) {
        case 'pending':  return QuestionApprovalStatus.pending;
        case 'rejected': return QuestionApprovalStatus.rejected;
        default:         return QuestionApprovalStatus.approved;
      }
    }

    final rawExpectedAnswer = includeDetails ? json['expected_answer'] : null;
    final expectedAnswerText = rawExpectedAnswer is List
        ? rawExpectedAnswer.map((e) => e.toString()).join(', ')
        : rawExpectedAnswer?.toString();

    final rawType = (json['type'] ?? 'multiple_choice').toString();
    final parsedType = parseQuestionType(rawType);
    final rawOptions = includeDetails ? ((json['options'] as List?) ?? const []) : const [];
    final expectedAnswerIds = rawExpectedAnswer is List
        ? rawExpectedAnswer.map((v) => v.toString()).toSet()
        : null;
    final options = rawOptions
        .whereType<Map>()
        .map((e) {
          final option = QuestionOption.fromJson(Map<String, dynamic>.from(e));
          final isCorrect = expectedAnswerIds != null
              ? expectedAnswerIds.contains(option.id)
              : rawExpectedAnswer?.toString() == option.id;
          return QuestionOption(
            id: option.id,
            text: option.text,
            isCorrect: option.isCorrect || isCorrect,
            explanation: option.explanation,
            orderIndex: option.orderIndex,
          );
        })
        .toList();

    final remoteId = json['id'] == null ? null : (json['id'] as num).toInt();
    final rawTags = (json['tags'] as List?) ?? const [];
    final rawLearningOutcomes = (json['learning_outcomes'] as List?) ?? const [];
    final topic = json['topic'] is Map
        ? Map<String, dynamic>.from(json['topic'] as Map)
        : const <String, dynamic>{};

    return QuestionModel(
      id: remoteId?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
      remoteId: remoteId,
      text: (json['question_text'] ?? '').toString(),
      type: parsedType,
      difficulty: parseQuestionDifficulty((json['difficulty'] ?? 'medium').toString()),
      source: parseQuestionSource((json['source'] ?? 'manual').toString()),
      approvalStatus: parseApproval((json['approval_status'] ?? 'approved').toString()),
      options: options,
      explanation: includeDetails ? json['explanation']?.toString() : null,
      expectedAnswer: expectedAnswerText,
      gradingRubric: includeDetails ? json['grading_rubric'] : null,
      correctOptionId: parsedType == QuestionType.multipleChoice ? expectedAnswerText : null,
      correctBool: parsedType == QuestionType.trueFalse ? expectedAnswerText?.toLowerCase() == 'true' : null,
      sampleAnswer: parsedType == QuestionType.shortAnswer || parsedType == QuestionType.essay ? expectedAnswerText : null,
      tags: rawTags.map((e) => e.toString()).toList(),
      usageCount: (json['usage_count'] as num?)?.toInt() ?? 0,
      successRate: json['success_rate'] == null ? null : (json['success_rate'] as num).toDouble(),
      averageTimeSeconds: json['average_time_seconds'] == null ? null : (json['average_time_seconds'] as num).toDouble(),
      maxScore: (json['max_score'] as num?)?.toInt() ?? 1,
      autoGradable: (json['auto_gradable'] as bool?) ?? true,
      courseId: json['course_id'] == null ? null : (json['course_id'] as num).toInt(),
      moduleId: json['module_id'] == null ? null : (json['module_id'] as num).toInt(),
      moduleName: json['module_name']?.toString(),
      materialId: json['material_id'] == null ? null : (json['material_id'] as num).toInt(),
      materialName: json['material_name']?.toString(),
      topicId: json['topic_id'] == null ? null : (json['topic_id'] as num).toInt(),
      topicName: json['topic_title']?.toString() ??
          json['topic_name']?.toString() ??
          topic['title']?.toString(),
      learningOutcomes: rawLearningOutcomes
          .whereType<Map>()
          .map((e) => QuestionLearningOutcomeRef.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
      createdBy: json['created_by'] == null ? null : (json['created_by'] as num).toInt(),
      createdAt: dt(json['created_at']),
      updatedAt: dt(json['updated_at'] ?? json['created_at']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'question_text': text,
      'type': type.backendValue,
      'difficulty': difficulty.backendValue,
      if (options.isNotEmpty) 'options': options.map((o) => o.toJson()).toList(),
      if (explanation != null) 'explanation': explanation,
      if (expectedAnswer != null) 'expected_answer': expectedAnswer,
      if (gradingRubric != null) 'grading_rubric': gradingRubric,
      if (tags.isNotEmpty) 'tags': tags,
      if (moduleId != null) 'module_id': moduleId,
      if (materialId != null) 'material_id': materialId,
      if (topicId != null) 'topic_id': topicId,
      if (createdBy != null) 'created_by': createdBy,
      if (averageTimeSeconds != null) 'average_time_seconds': averageTimeSeconds,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }
}

/// Lightweight quiz built from selected questions (in-memory)
class QuizDraft {
  final String id;
  final String title;
  final String? description;
  final List<QuestionModel> questions;
  final int timeLimitMinutes;
  final bool shuffleQuestions;

  const QuizDraft({
    required this.id,
    required this.title,
    this.description,
    this.questions = const [],
    this.timeLimitMinutes = 60,
    this.shuffleQuestions = true,
  });
}
