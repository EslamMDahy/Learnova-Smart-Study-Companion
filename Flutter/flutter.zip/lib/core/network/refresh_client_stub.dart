import 'dart:convert';

import 'package:dio/dio.dart';

import 'api_exceptions.dart';
import 'dio_adapter_config.dart';
import 'refresh_client.dart';

class _DioRefreshClient implements RefreshClient {
  _DioRefreshClient(this._dio) {
    configureDioAdapter(_dio);
  }

  final Dio _dio;

  String _refreshErrorCode(int? status, DioExceptionType type) {
    if (status == 401 || status == 403) return 'REFRESH_AUTH_FAILED';
    if (status != null && status >= 500) return 'REFRESH_SERVER';
    if (type == DioExceptionType.connectionTimeout ||
        type == DioExceptionType.receiveTimeout ||
        type == DioExceptionType.sendTimeout) {
      return 'REFRESH_TIMEOUT';
    }
    if (type == DioExceptionType.connectionError) return 'REFRESH_NETWORK';
    return 'REFRESH_FAILED';
  }

  @override
  Future<String> refresh({required String url}) async {
    try {
      final res = await _dio.post<dynamic>(
        url,
        data: const {},
        options: Options(
          sendTimeout: const Duration(seconds: 15),
          receiveTimeout: const Duration(seconds: 15),
          headers: const {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
        ),
      );

      final data = res.data;
      Map<String, dynamic> decoded;
      if (data is Map) {
        decoded = data.cast<String, dynamic>();
      } else if (data is String) {
        decoded = (jsonDecode(data) as Map).cast<String, dynamic>();
      } else {
        decoded = <String, dynamic>{};
      }

      final root = (decoded['data'] is Map)
          ? (decoded['data'] as Map).cast<String, dynamic>()
          : decoded;

      final token =
          (root['access_token'] ?? root['token'] ?? root['accessToken'])
              ?.toString();

      if (token == null || token.trim().isEmpty) {
        throw ApiException('Invalid refresh response.', code: 'REFRESH_INVALID');
      }
      return token.trim();
    } on DioException catch (e) {
      final status = e.response?.statusCode;
      throw ApiException(
        'Refresh failed.',
        statusCode: status,
        code: _refreshErrorCode(status, e.type),
      );
    }
  }
}

/// Used by conditional import factory.
RefreshClient createRefreshClientImpl() => _DioRefreshClient(Dio());
